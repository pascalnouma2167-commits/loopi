-- Loopi Makarna v6 -> v7 Dükkan Yönetimi
-- Çalıştırmadan önce veritabanı yedeği alın.
ALTER TABLE products ADD COLUMN ingredients TEXT NULL AFTER description;
ALTER TABLE products ADD COLUMN allergen TEXT NULL AFTER ingredients;
ALTER TABLE products ADD COLUMN storage_conditions TEXT NULL AFTER allergen;
ALTER TABLE products ADD COLUMN origin_note TEXT NULL AFTER storage_conditions;
ALTER TABLE products ADD COLUMN nutrition_json LONGTEXT NULL AFTER origin_note;
-- v6'da old_price zaten eklenmiştir. Yeni kurulumlarda schema.sql alanı doğrudan içerir.
