INSERT INTO shipping_settings (id,fee,free_threshold,company,estimate) VALUES (1,79,750,'Yurtiçi / anlaşmalı kargo','1–3 iş günü') ON DUPLICATE KEY UPDATE id=id;
INSERT INTO products (id,name,category,description,unit,price,old_price,vat_rate,stock,badge,emoji) VALUES
(1,'Sebzeli Tarhana','Temel Gıda','Geleneksel usulle hazırlanmış sebzeli kuru tarhana.','500 g',120,150,10,60,'Çok Satan','🥣'),
(2,'Domates Salçası','Temel Gıda','Yoğun kıvamlı ev yapımı domates salçası.','650 g',119,140,10,60,'','🍅'),
(3,'Sade Erişte','Makarna','Ev yapımı kesme sade erişte.','500 g',81,90,10,50,'','🍜'),
(4,'Çilek Reçeli','Kahvaltılık','Mevsim çilekleriyle küçük partilerde hazırlanır.','380 g',120,160,10,50,'','🍓'),
(5,'Tahin','Kahvaltılık','Özenle kavrulmuş susamdan yoğun kıvamlı tahin.','500 g',170,200,10,40,'','🥄'),
(6,'Üzüm Pekmezi','Kahvaltılık','Yoğun kıvamlı geleneksel üzüm pekmezi.','460 g',149,NULL,10,40,'Yeni','🍇'),
(7,'Biber Salçası','Temel Gıda','Kırmızı biberden hazırlanmış yoğun ev salçası.','650 g',129,NULL,10,35,'Yeni','🌶️'),
(8,'Kepekli Tarhana','Temel Gıda','Kepekli unla hazırlanan geleneksel tarhana.','500 g',109,NULL,10,30,'Yeni','🥣'),
(9,'İncir Reçeli','Kahvaltılık','Olgun incirlerle küçük partilerde hazırlanır.','380 g',139,NULL,10,32,'','🫙'),
(10,'Tam Buğday Erişte','Makarna','Tam buğday unuyla hazırlanmış ev eriştesi.','500 g',99,NULL,10,30,'Yeni','🍜'),
(11,'Kayısı Reçeli','Kahvaltılık','Mevsim kayısılarıyla ev usulü hazırlanır.','380 g',135,NULL,10,25,'','🫙'),
(12,'Köy Tarhanası','Temel Gıda','Uzun fermantasyonlu klasik köy tarhanası.','500 g',129,NULL,10,25,'Çok Satan','🥣')
ON DUPLICATE KEY UPDATE name=VALUES(name),category=VALUES(category),description=VALUES(description),unit=VALUES(unit),price=VALUES(price),old_price=VALUES(old_price),vat_rate=VALUES(vat_rate),stock=VALUES(stock),badge=VALUES(badge),emoji=VALUES(emoji);
INSERT INTO campaigns (slug,kicker,title,city,goal_amount,collected_amount,supporters_count,description,impact,next_step,status,emoji) VALUES
('okul-cantasi','Eğitim','Çocuklara Okul Çantası Desteği','Zonguldak',50000,0,0,'Yeni eğitim döneminde ihtiyaç sahibi çocukların okul çantası ve temel kırtasiye ihtiyaçlarına destek oluyoruz.','Katkılar okul başlangıç setlerine dönüşüyor.','Hedef tamamlandığında setler teslim edilecek.','active','🎒'),
('bir-sofra','Dayanışma','Bir Sofra da Sen Kur','İstanbul',50000,0,0,'İhtiyaç sahibi ailelerin temel gıda paketlerine katkı sağlıyoruz.','Katkılar temel gıda paketlerine dönüşüyor.','Hedefe ulaşıldığında paketleme ve teslim başlayacak.','active','🍲'),
('mama-destegi','Can Dostlar','Sokak Canlarına Mama Desteği','Ankara',30000,0,0,'Sokakta yaşayan hayvanların mama ve temel bakım ihtiyaçlarına destek oluyoruz.','Katkılar mama desteğine dönüşüyor.','Hedef tamamlanınca dağıtım yapılacak.','active','🐾')
ON DUPLICATE KEY UPDATE title=VALUES(title);
