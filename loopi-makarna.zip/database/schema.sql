CREATE TABLE IF NOT EXISTS users (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 phone VARCHAR(40) NOT NULL,
 city VARCHAR(80) NOT NULL,
 district VARCHAR(100) NOT NULL,
 address TEXT NOT NULL,
 role ENUM('customer','staff','admin') NOT NULL DEFAULT 'customer',
 email_verified_at DATETIME NULL,
 totp_secret VARCHAR(64) NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS products (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(180) NOT NULL,
 category VARCHAR(100) NOT NULL,
 description TEXT NOT NULL,
 ingredients TEXT NULL,
 allergen TEXT NULL,
 storage_conditions TEXT NULL,
 origin_note TEXT NULL,
 nutrition_json LONGTEXT NULL,
 unit VARCHAR(80) NOT NULL,
 price DECIMAL(12,2) NOT NULL,
 old_price DECIMAL(12,2) NULL,
 vat_rate DECIMAL(5,2) NOT NULL DEFAULT 10.00,
 stock INT NOT NULL DEFAULT 0,
 image_path VARCHAR(255) NULL,
 badge VARCHAR(80) NULL,
 emoji VARCHAR(20) NULL,
 active TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS campaigns (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 slug VARCHAR(100) NOT NULL UNIQUE,
 kicker VARCHAR(100) NOT NULL,
 title VARCHAR(180) NOT NULL,
 city VARCHAR(80) NOT NULL,
 goal_amount DECIMAL(12,2) NOT NULL,
 collected_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
 supporters_count INT NOT NULL DEFAULT 0,
 description TEXT NOT NULL,
 impact TEXT NULL,
 next_step TEXT NULL,
 status ENUM('active','completed','archived') NOT NULL DEFAULT 'active',
 result_title VARCHAR(220) NULL,
 result_text TEXT NULL,
 result_image VARCHAR(255) NULL,
 emoji VARCHAR(20) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS shipping_settings (
 id TINYINT PRIMARY KEY,
 fee DECIMAL(12,2) NOT NULL DEFAULT 79,
 free_threshold DECIMAL(12,2) NOT NULL DEFAULT 750,
 company VARCHAR(120) NOT NULL,
 estimate VARCHAR(120) NOT NULL,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS coupons (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 code VARCHAR(60) NOT NULL UNIQUE,
 type ENUM('percent','fixed') NOT NULL,
 value DECIMAL(12,2) NOT NULL,
 min_total DECIMAL(12,2) NOT NULL DEFAULT 0,
 max_uses INT NULL,
 uses_count INT NOT NULL DEFAULT 0,
 active TINYINT(1) NOT NULL DEFAULT 1,
 expires_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS orders (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_no VARCHAR(40) NOT NULL UNIQUE,
 user_id BIGINT UNSIGNED NOT NULL,
 campaign_id BIGINT UNSIGNED NULL,
 coupon_id BIGINT UNSIGNED NULL,
 subtotal DECIMAL(12,2) NOT NULL,
 discount DECIMAL(12,2) NOT NULL DEFAULT 0,
 shipping_fee DECIMAL(12,2) NOT NULL DEFAULT 0,
 total DECIMAL(12,2) NOT NULL,
 goodwill_amount DECIMAL(12,2) NOT NULL,
 payment_provider VARCHAR(40) NOT NULL DEFAULT 'paytr',
 payment_status ENUM('pending','paid','failed','refunded','cancelled') NOT NULL DEFAULT 'pending',
 order_status ENUM('new','preparing','shipped','delivered','cancelled','returned') NOT NULL DEFAULT 'new',
 shipping_company VARCHAR(120) NULL,
 shipping_slug VARCHAR(100) NULL,
 tracking_no VARCHAR(120) NULL,
 shipping_note VARCHAR(255) NULL,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL,
 phone VARCHAR(40) NOT NULL,
 city VARCHAR(80) NOT NULL,
 district VARCHAR(100) NOT NULL,
 address TEXT NOT NULL,
 invoice_type ENUM('individual','company') NOT NULL DEFAULT 'individual',
 invoice_title VARCHAR(190) NULL,
 tax_office VARCHAR(120) NULL,
 tax_number VARCHAR(30) NULL,
 paid_at DATETIME NULL,
 stock_released_at DATETIME NULL,
 goodwill_applied_at DATETIME NULL,
 coupon_counted_at DATETIME NULL,
 invoice_status ENUM('not_requested','pending','issued','failed') NOT NULL DEFAULT 'not_requested',
 invoice_provider_ref VARCHAR(190) NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_orders_user FOREIGN KEY (user_id) REFERENCES users(id),
 CONSTRAINT fk_orders_campaign FOREIGN KEY (campaign_id) REFERENCES campaigns(id),
 CONSTRAINT fk_orders_coupon FOREIGN KEY (coupon_id) REFERENCES coupons(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS subscriptions (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 campaign_id BIGINT UNSIGNED NOT NULL,
 plan_code ENUM('mini','standard','family') NOT NULL,
 plan_name VARCHAR(120) NOT NULL,
 frequency_months TINYINT UNSIGNED NOT NULL DEFAULT 1,
 price DECIMAL(12,2) NOT NULL,
 goodwill_amount DECIMAL(12,2) NOT NULL,
 status ENUM('payment_pending','active','paused','cancelled') NOT NULL DEFAULT 'payment_pending',
 start_date DATE NOT NULL,
 next_delivery_date DATE NOT NULL,
 payment_provider VARCHAR(40) NOT NULL DEFAULT 'paytr',
 payment_reference VARCHAR(190) NULL,
 paused_at DATETIME NULL,
 cancelled_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 INDEX idx_subscriptions_user (user_id,status),
 INDEX idx_subscriptions_due (status,next_delivery_date),
 CONSTRAINT fk_subscriptions_user FOREIGN KEY (user_id) REFERENCES users(id),
 CONSTRAINT fk_subscriptions_campaign FOREIGN KEY (campaign_id) REFERENCES campaigns(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS order_items (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_id BIGINT UNSIGNED NOT NULL,
 product_id BIGINT UNSIGNED NOT NULL,
 product_name VARCHAR(180) NOT NULL,
 unit_price DECIMAL(12,2) NOT NULL,
 vat_rate DECIMAL(5,2) NOT NULL,
 quantity INT NOT NULL,
 line_total DECIMAL(12,2) NOT NULL,
 CONSTRAINT fk_items_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
 CONSTRAINT fk_items_product FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS reviews (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 product_id BIGINT UNSIGNED NOT NULL,
 rating TINYINT NOT NULL,
 body VARCHAR(800) NOT NULL,
 approved TINYINT(1) NOT NULL DEFAULT 1,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uniq_user_product (user_id,product_id),
 CONSTRAINT fk_reviews_user FOREIGN KEY (user_id) REFERENCES users(id),
 CONSTRAINT fk_reviews_product FOREIGN KEY (product_id) REFERENCES products(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS returns (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 order_id BIGINT UNSIGNED NOT NULL,
 user_id BIGINT UNSIGNED NOT NULL,
 reason VARCHAR(255) NOT NULL,
 details TEXT NULL,
 status ENUM('requested','approved','rejected','received','refunded') NOT NULL DEFAULT 'requested',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 CONSTRAINT fk_returns_order FOREIGN KEY (order_id) REFERENCES orders(id),
 CONSTRAINT fk_returns_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_resets (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expires_at DATETIME NOT NULL,
 used_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_reset_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS login_attempts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 ip VARCHAR(64) NOT NULL,
 email VARCHAR(190) NOT NULL,
 success TINYINT(1) NOT NULL DEFAULT 0,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_login_attempts (ip,email,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS city_contributions (
 city VARCHAR(80) PRIMARY KEY,
 amount DECIMAL(12,2) NOT NULL DEFAULT 0,
 orders_count INT NOT NULL DEFAULT 0,
 updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS newsletters (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 email VARCHAR(190) NOT NULL UNIQUE,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS corporate_quote_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 company VARCHAR(190) NOT NULL,
 contact_name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL,
 phone VARCHAR(40) NOT NULL,
 box_name VARCHAR(190) NOT NULL,
 quantity INT UNSIGNED NOT NULL,
 delivery_date DATE NULL,
 notes TEXT NULL,
 status ENUM('new','contacted','quoted','won','lost') NOT NULL DEFAULT 'new',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_corporate_status (status,created_at),
 INDEX idx_corporate_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE IF NOT EXISTS email_verifications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expires_at DATETIME NOT NULL,
 used_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_verify_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS request_attempts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 action_name VARCHAR(60) NOT NULL,
 ip VARCHAR(64) NOT NULL,
 identity_key VARCHAR(190) NOT NULL DEFAULT '',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_request_attempts (action_name,ip,identity_key,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 actor_user_id BIGINT UNSIGNED NULL,
 actor_role VARCHAR(30) NULL,
 action_name VARCHAR(100) NOT NULL,
 entity_type VARCHAR(80) NOT NULL,
 entity_id VARCHAR(80) NULL,
 old_data JSON NULL,
 new_data JSON NULL,
 reason VARCHAR(255) NULL,
 ip VARCHAR(64) NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_audit_actor (actor_user_id,created_at),
 INDEX idx_audit_entity (entity_type,entity_id,created_at),
 CONSTRAINT fk_audit_actor FOREIGN KEY (actor_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
