CREATE TABLE IF NOT EXISTS corporate_quote_requests (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 company VARCHAR(190) NOT NULL,
 contact_name VARCHAR(120) NOT NULL,
 email VARCHAR(190) NOT NULL,
 phone VARCHAR(40) NOT NULL,
 box_name VARCHAR(190) NOT NULL,
 quantity INT UNSIGNED NOT NULL,
 delivery_date DATE NULL,
 notes TEXT NULL,
 status ENUM('new','contacted','quoted','won','lost') NOT NULL DEFAULT 'new',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_corporate_status (status,created_at),
 INDEX idx_corporate_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
