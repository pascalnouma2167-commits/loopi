-- Loopi Makarna v2 -> v3 geçişi. Yalnızca bir kez çalıştırın ve önce yedek alın.
ALTER TABLE users
  ADD COLUMN email_verified_at DATETIME NULL AFTER role,
  ADD COLUMN totp_secret VARCHAR(64) NULL AFTER email_verified_at;

-- Mevcut yönetim hesaplarının girişte 2FA kurulumuna yönlendirilmesi için totp_secret NULL bırakılır.
-- V2'de e-posta doğrulaması olmadığı için mevcut müşterilerin kilitlenmemesi adına mevcut hesaplar doğrulanmış kabul edilir.
UPDATE users SET email_verified_at = COALESCE(email_verified_at, NOW());

ALTER TABLE orders
  ADD COLUMN paid_at DATETIME NULL AFTER tax_number,
  ADD COLUMN stock_released_at DATETIME NULL AFTER paid_at,
  ADD COLUMN goodwill_applied_at DATETIME NULL AFTER stock_released_at,
  ADD COLUMN coupon_counted_at DATETIME NULL AFTER goodwill_applied_at,
  ADD COLUMN invoice_status ENUM('not_requested','pending','issued','failed') NOT NULL DEFAULT 'not_requested' AFTER coupon_counted_at,
  ADD COLUMN invoice_provider_ref VARCHAR(190) NULL AFTER invoice_status;

-- V2'de paid olan siparişlerin yeniden kampanya/kupon sayımına girmesini engelle.
UPDATE orders SET paid_at=COALESCE(paid_at,updated_at), goodwill_applied_at=COALESCE(goodwill_applied_at,updated_at), coupon_counted_at=CASE WHEN coupon_id IS NOT NULL THEN COALESCE(coupon_counted_at,updated_at) ELSE NULL END WHERE payment_status='paid';

CREATE TABLE email_verifications (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 user_id BIGINT UNSIGNED NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expires_at DATETIME NOT NULL,
 used_at DATETIME NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_verify_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE request_attempts (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 action_name VARCHAR(60) NOT NULL,
 ip VARCHAR(64) NOT NULL,
 identity_key VARCHAR(190) NOT NULL DEFAULT '',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_request_attempts (action_name,ip,identity_key,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE audit_logs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 actor_user_id BIGINT UNSIGNED NULL,
 actor_role VARCHAR(30) NULL,
 action_name VARCHAR(100) NOT NULL,
 entity_type VARCHAR(80) NOT NULL,
 entity_id VARCHAR(80) NULL,
 old_data JSON NULL,
 new_data JSON NULL,
 reason VARCHAR(255) NULL,
 ip VARCHAR(64) NOT NULL,
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_audit_actor (actor_user_id,created_at),
 INDEX idx_audit_entity (entity_type,entity_id,created_at),
 CONSTRAINT fk_audit_actor FOREIGN KEY (actor_user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Veri güvenliği: önce v2 toplulaştırılmış değerlerin tek seferlik snapshot'ını al.
-- Bu tablolar migration sonrası doğrulama/geri dönüş incelemesi için tutulabilir.
CREATE TABLE IF NOT EXISTS migration_v3_campaign_snapshot AS
SELECT id, collected_amount, supporters_count, NOW() AS snapshot_at FROM campaigns;
CREATE TABLE IF NOT EXISTS migration_v3_city_snapshot AS
SELECT city, amount, orders_count, NOW() AS snapshot_at FROM city_contributions;

-- Demo seed rakamlarına güvenmek yerine gerçek ödenmiş siparişlerden kampanya toplamlarını yeniden üret.
UPDATE campaigns c
LEFT JOIN (
  SELECT campaign_id, ROUND(SUM(goodwill_amount),2) AS collected_amount, COUNT(*) AS supporters_count
  FROM orders
  WHERE payment_status='paid' AND campaign_id IS NOT NULL
  GROUP BY campaign_id
) x ON x.campaign_id=c.id
SET c.collected_amount=COALESCE(x.collected_amount,0),
    c.supporters_count=COALESCE(x.supporters_count,0);

-- Şehir katkıları da gerçek ödenmiş siparişlerden yeniden oluşturulur.
DELETE FROM city_contributions;
INSERT INTO city_contributions(city,amount,orders_count)
SELECT city, ROUND(SUM(goodwill_amount),2), COUNT(*)
FROM orders
WHERE payment_status='paid' AND city IS NOT NULL AND TRIM(city)<>''
GROUP BY city;

