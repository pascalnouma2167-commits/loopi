-- Loopi Makarna v5 -> v6 Dükkan alanları
ALTER TABLE products ADD COLUMN old_price DECIMAL(12,2) NULL AFTER price;
-- İndirim göstermek için admin panelinde Eski fiyat alanına normal liste fiyatını, Fiyat alanına indirimli satış fiyatını girin.
