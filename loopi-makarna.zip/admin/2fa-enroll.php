<?php
declare(strict_types=1);
require dirname(__DIR__).'/app/bootstrap.php';
send_csp(['https://cdnjs.cloudflare.com']);
$uid=(int)($_SESSION['pending_admin_uid']??0);
$started=(int)($_SESSION['pending_admin_started']??0);
if(!$uid||time()-$started>600){unset($_SESSION['pending_admin_uid'],$_SESSION['pending_admin_started'],$_SESSION['pending_totp_secret']);header('Location: login.php');exit;}
$s=db()->prepare("SELECT id,name,email,role,totp_secret FROM users WHERE id=? AND active=1 AND role IN ('admin','staff')");
$s->execute([$uid]);$u=$s->fetch();if(!$u){header('Location: login.php');exit;}
if(!empty($u['totp_secret'])){header('Location: 2fa-verify.php');exit;}
if(empty($_SESSION['pending_totp_secret']))$_SESSION['pending_totp_secret']=totp_secret();
$secret=(string)$_SESSION['pending_totp_secret'];
$issuer=(string)cfg('app.name','Loopi Makarna');
$otpauth=totp_otpauth_uri($secret,(string)$u['email'],$issuer);
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $identity=(string)$uid;
  if(rate_limit_hit('admin_2fa_enroll',$identity,8,15)){$msg='Çok fazla kurulum doğrulama denemesi. 15 dakika sonra tekrar deneyin.';}
  else{
    rate_limit_record('admin_2fa_enroll',$identity);
    $code=clean_text($_POST['code']??'',6);
    if(totp_verify($secret,$code)){
      db()->prepare('UPDATE users SET totp_secret=? WHERE id=?')->execute([$secret,$uid]);
      audit_log('2fa_enroll','user',$uid,null,['enabled'=>true],'Yönetim hesabı 2FA kurulumu',['id'=>$uid,'role'=>$u['role']]);
      $_SESSION['uid']=$uid;
      unset($_SESSION['pending_admin_uid'],$_SESSION['pending_admin_started'],$_SESSION['pending_totp_secret']);
      session_regenerate_id(true);header('Location: index.php');exit;
    }
    $msg='Kod doğrulanamadı.';
  }
}
?><!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>2FA Kur · Loopi Makarna</title><link rel="stylesheet" href="../styles.css"></head><body><main class="container" style="padding:60px 20px"><div class="card" style="max-width:600px;margin:auto;padding:30px"><h1>2FA kurulumunu tamamla</h1><p>Authenticator uygulamanla QR kodu okutabilir veya anahtarı manuel ekleyebilirsin.</p><div id="qrcode" data-otpauth="<?=htmlspecialchars($otpauth,ENT_QUOTES)?>" style="margin:18px 0"></div><p><a class="btn soft" href="<?=htmlspecialchars($otpauth,ENT_QUOTES)?>">Authenticator uygulamasında aç</a></p><p style="font-size:21px;word-break:break-all"><code><?=htmlspecialchars($secret)?></code></p><form method="post"><label>6 haneli kod<input class="input" name="code" inputmode="numeric" pattern="\d{6}" maxlength="6" required></label><button class="btn primary full" style="margin-top:14px">Doğrula ve giriş yap</button></form><p><?=htmlspecialchars($msg)?></p></div></main><script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js" integrity="sha512-CNgIRecGo7nphbeZ04Sc13ka07paqdeTu0WR1IM4kNcpmBAUSHSQX0FslNhTDadL4O5SAGapGt4FodqL8My0mA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script><script src="2fa-enroll.js"></script></body></html>
